﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AICtrl : MonoBehaviour {

    public GameObject Char1;

    private Rigidbody2D rb2d;

    public float speed = 100f;
    public float detectionDistance = 200f;

    private float distance;
    private float distanceX;
    private float distanceY;
    private float collide;

    public float RandomWait;
    public float RandomNumber;
    
    
    public bool XlargerThanY;
    public bool diagonal;

    private Vector3 currentPos;



    // Use this for initialization
    void Start () {
        rb2d = GetComponent<Rigidbody2D>();
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        if (Input.GetKey(KeyCode.E))
        {
            Destroy(GetComponent<BoxCollider2D>());
        }

        distance = Mathf.Sqrt(Mathf.Pow(currentPos.x - Char1.transform.position.x, 2.0f) + Mathf.Pow(currentPos.y - Char1.transform.position.y, 2.0f));
        distanceX = Mathf.Abs(currentPos.x - Char1.transform.position.x);
        distanceY = Mathf.Abs(currentPos.y - Char1.transform.position.y);
        currentPos = transform.position;
       

        if (distanceX>distanceY)
        {
            XlargerThanY = true;
        }
        else
        {
            XlargerThanY = false;
        }

        if (!Char1.GetComponent<Ctrl>().IsPaused)
        {
            AIMove();
        }
	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        collide = 1;
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        collide = 2;
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        collide = 3;
    }

    void AIMove()
    {
        float moveHorizontal = 0;
        float moveVertical = 0;

        if (distance < detectionDistance && distance > 5)
        {
            diagonal = false;
            if (((XlargerThanY && Mathf.Rad2Deg * Mathf.Asin((Mathf.Round((distanceY / distance) * 100f)) / 100f) > 22.5) &&
                (XlargerThanY && Mathf.Rad2Deg * Mathf.Asin((Mathf.Round((distanceY / distance) * 100f)) / 100f) < 67.5)) ||
                ((!XlargerThanY && Mathf.Rad2Deg * Mathf.Asin((Mathf.Round((distanceX / distance) * 100f)) / 100f) > 22.5) &&
                (!XlargerThanY && Mathf.Rad2Deg * Mathf.Asin((Mathf.Round((distanceX / distance) * 100f)) / 100f) < 67.5)))
            {
                diagonal = true;
            }
            if (diagonal)
            {
                if (currentPos.x > Char1.transform.position.x)
                {
                    moveHorizontal = -speed/2;
                }
                else
                {
                    moveHorizontal = speed/2;
                }
                if (currentPos.y > Char1.transform.position.y)
                {
                    moveVertical = -speed/2;
                }
                else
                {
                    moveVertical = speed/2;
                }
            }
            else
            {
                if (XlargerThanY)
                {
                    if (currentPos.x > Char1.transform.position.x)
                    {
                        moveHorizontal = -speed;
                    }
                    else
                    {
                        moveHorizontal = speed;
                    }
                }
                else
                {
                    if (currentPos.y > Char1.transform.position.y)
                    {
                        moveVertical = -speed;
                    }
                    else
                    {
                        moveVertical = speed;
                    }
                }
            }
        }
        else
        {
            if (RandomWait == 0)
            {
                RandomNumber = Random.Range(1, 9);
                RandomWait = Random.Range(20, 46);
            } 

            if (RandomNumber == 1)
            {
                moveHorizontal = -speed;
            }
            if (RandomNumber == 2)
            {
                moveHorizontal = -speed/2;
                moveVertical = speed/2;
            }
            if (RandomNumber == 3)
            {
                moveVertical = speed;
            }
            if (RandomNumber == 4)
            {
                moveHorizontal = speed / 2;
                moveVertical = speed / 2;
            }
            if (RandomNumber == 5)
            {
                moveHorizontal = speed;
            }
            if (RandomNumber == 6)
            {
                moveHorizontal = speed / 2;
                moveVertical = -speed / 2;
            }
            if (RandomNumber == 7)
            {
                moveVertical = -speed;
            }
            if (RandomNumber == 8)
            {
                moveHorizontal = -speed / 2;
                moveVertical = -speed / 2;
            }
            RandomWait--;
        }
        Vector2 movement = new Vector2(moveHorizontal, moveVertical);

        rb2d.MovePosition(rb2d.position + movement * Time.deltaTime);
    }
}
