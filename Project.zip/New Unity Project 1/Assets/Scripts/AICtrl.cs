﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AICtrl : MonoBehaviour {

    public GameObject Char1;

    public float speed = 100f;
    public float detectionDistance = 200f;

    private float distance;
    private float distanceX;
    private float distanceY;

    private bool XlargerThanY;
    private bool diagonal;


    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 currentPos = transform.position;
        distance = Mathf.Sqrt(Mathf.Pow(currentPos.x - Char1.transform.position.x, 2.0f) + Mathf.Pow(currentPos.y - Char1.transform.position.y, 2.0f));
        distanceX = Mathf.Abs(currentPos.x - Char1.transform.position.x);
        distanceY = Mathf.Abs(currentPos.y - Char1.transform.position.y);
        if (distanceX>distanceY)
        {
            XlargerThanY = true;
        }
        else
        {
            XlargerThanY = false;
        }
        if (!Char1.GetComponent<Ctrl>().IsPaused)
        {
            if (distance < detectionDistance && distance > 5)
            {
                diagonal = false;
                if (((XlargerThanY && Mathf.Rad2Deg * Mathf.Asin(distanceY / distance) > 22.5) &&
                    (XlargerThanY && Mathf.Rad2Deg * Mathf.Asin(distanceY / distance) < 67.5)) ||
                    ((!XlargerThanY && Mathf.Rad2Deg * Mathf.Asin(distanceX / distance) > 22.5) &&
                    (!XlargerThanY && Mathf.Rad2Deg * Mathf.Asin(distanceX / distance) < 67.5)))
                {
                    diagonal = true;
                }
                if (diagonal)
                {
                    if (currentPos.x > Char1.transform.position.x)
                    {
                        transform.position += Vector3.left * (speed / 2) * Time.deltaTime;
                    }
                    else
                    {
                        transform.position += Vector3.right * (speed / 2) * Time.deltaTime;
                    }
                    if (currentPos.y > Char1.transform.position.y)
                    {
                        transform.position += Vector3.down * (speed / 2) * Time.deltaTime;
                    }
                    else
                    {
                        transform.position += Vector3.up * (speed / 2) * Time.deltaTime;
                    }
                }
                else
                {
                    if (XlargerThanY)
                    {
                        if (currentPos.x > Char1.transform.position.x)
                        {
                            transform.position += Vector3.left * speed * Time.deltaTime;
                        }
                        else
                        {
                            transform.position += Vector3.right * speed * Time.deltaTime;
                        }
                    }
                    else
                    {
                        if (currentPos.y > Char1.transform.position.y)
                        {
                            transform.position += Vector3.down * speed * Time.deltaTime;
                        }
                        else
                        {
                            transform.position += Vector3.up * speed * Time.deltaTime;
                        }
                    }
                }
            }
            else
            {

            }
        }
	}
}
