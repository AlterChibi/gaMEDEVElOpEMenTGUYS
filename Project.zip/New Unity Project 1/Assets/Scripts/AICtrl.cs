﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AICtrl : MonoBehaviour {

    public GameObject Char1;
    public GameObject BorderLeft;
    public GameObject BorderRight;
    public GameObject BorderTop;
    public GameObject BorderBottom;

    public float speed = 100f;
    public float detectionDistance = 200f;

    private float distance;
    private float distanceX;
    private float distanceY;
    public float RandomWait;
    public float RandomNumber;
    public float BorderLeftT;
    public float BorderRightT;
    public float BorderTopT;
    public float BorderBottomT;


    private bool XlargerThanY;
    private bool diagonal;

    private Vector3 currentPos;



    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        
        distance = Mathf.Sqrt(Mathf.Pow(currentPos.x - Char1.transform.position.x, 2.0f) + Mathf.Pow(currentPos.y - Char1.transform.position.y, 2.0f));
        distanceX = Mathf.Abs(currentPos.x - Char1.transform.position.x);
        distanceY = Mathf.Abs(currentPos.y - Char1.transform.position.y);
        currentPos = transform.position;
        BorderLeftT = BorderLeft.GetComponent<BoxCollideTrigger>().collide;
        BorderRightT = BorderRight.GetComponent<BoxCollideTrigger>().collide;
        BorderTopT = BorderTop.GetComponent<BoxCollideTrigger>().collide;
        BorderBottomT = BorderBottom.GetComponent<BoxCollideTrigger>().collide;

        if (distanceX>distanceY)
        {
            XlargerThanY = true;
        }
        else
        {
            XlargerThanY = false;
        }

        if (!Char1.GetComponent<Ctrl>().IsPaused)
        {
            AIMove();

            
        }
	}

    void AIMove()
    {
        if (distance < detectionDistance && distance > 5)
        {
            diagonal = false;
            if (((XlargerThanY && Mathf.Rad2Deg * Mathf.Asin(Mathf.Round(distanceY / distance)) > 22.5) &&
                (XlargerThanY && Mathf.Rad2Deg * Mathf.Asin(Mathf.Round(distanceY / distance)) < 67.5)) ||
                ((!XlargerThanY && Mathf.Rad2Deg * Mathf.Asin(Mathf.Round(distanceX / distance)) > 22.5) &&
                (!XlargerThanY && Mathf.Rad2Deg * Mathf.Asin(Mathf.Round(distanceX / distance)) < 67.5)))
            {
                diagonal = true;
            }
            if (diagonal)
            {
                if (currentPos.x > Char1.transform.position.x && !(BorderLeftT == 2 || BorderLeftT == 1))
                {
                    transform.position += Vector3.left * (speed / 2) * Time.deltaTime;
                }
                else if (!(BorderRightT == 2 || BorderRightT == 1))
                {
                    transform.position += Vector3.right * (speed / 2) * Time.deltaTime;
                }
                if (currentPos.y > Char1.transform.position.y && !(BorderBottomT == 2 || BorderBottomT == 1))
                {
                    transform.position += Vector3.down * (speed / 2) * Time.deltaTime;
                }
                else if (!(BorderTopT == 2 || BorderTopT == 1))
                {
                    transform.position += Vector3.up * (speed / 2) * Time.deltaTime;
                }
            }
            else
            {
                if (XlargerThanY)
                {
                    if (currentPos.x > Char1.transform.position.x && !(BorderLeftT == 2 || BorderLeftT == 1))
                    {
                        transform.position += Vector3.left * speed * Time.deltaTime;
                    }
                    else if (!(BorderRightT == 2 || BorderRightT == 1))
                    {
                        transform.position += Vector3.right * speed * Time.deltaTime;
                    }
                }
                else
                {
                    if (currentPos.y > Char1.transform.position.y && !(BorderBottomT == 2 || BorderBottomT == 1))
                    {
                        transform.position += Vector3.down * speed * Time.deltaTime;
                    }
                    else if (!(BorderTopT == 2 || BorderTopT == 1))
                    {
                        transform.position += Vector3.up * speed * Time.deltaTime;
                    }
                }
            }
        }
        else
        {
            if (RandomWait == 0)
            {
                RandomNumber = Random.Range(1, 9);
                RandomWait = Random.Range(20, 46);
            } 

            if (RandomNumber == 1 && !(BorderLeftT == 2 || BorderLeftT == 1))
            {
                transform.position += Vector3.left * speed * Time.deltaTime;
            }
            if (RandomNumber == 2 && !(BorderLeftT == 2 || BorderLeftT == 1) && !(BorderTopT == 2 || BorderTopT == 1))
            {
                transform.position += Vector3.left * (speed / 2) * Time.deltaTime;
                transform.position += Vector3.up * (speed / 2) * Time.deltaTime;
            }
            if (RandomNumber == 3 && !(BorderTopT == 2 || BorderTopT == 1))
            {
                transform.position += Vector3.up * speed * Time.deltaTime;
            }
            if (RandomNumber == 4 && !(BorderRightT == 2 || BorderRightT == 1) && !(BorderTopT == 2 || BorderTopT == 1))
            {
                transform.position += Vector3.right * (speed / 2) * Time.deltaTime;
                transform.position += Vector3.up * (speed / 2) * Time.deltaTime;
            }
            if (RandomNumber == 5 && !(BorderRightT == 2 || BorderRightT == 1))
            {
                transform.position += Vector3.right * speed * Time.deltaTime;
            }
            if (RandomNumber == 6 && !(BorderRightT == 2 || BorderRightT == 1) && !(BorderBottomT == 2 || BorderBottomT == 1))
            {
                transform.position += Vector3.right * (speed / 2) * Time.deltaTime;
                transform.position += Vector3.down * (speed / 2) * Time.deltaTime;
            }
            if (RandomNumber == 7 && !(BorderBottomT == 2 || BorderBottomT == 1))
            {
                transform.position += Vector3.down * speed * Time.deltaTime;
            }
            if (RandomNumber == 8 && !(BorderLeftT == 2 || BorderLeftT == 1) && !(BorderBottomT == 2 || BorderBottomT == 1))
            {
                transform.position += Vector3.left * (speed / 2) * Time.deltaTime;
                transform.position += Vector3.down * (speed / 2) * Time.deltaTime;
            }
            RandomWait--;
        }
    }
}
