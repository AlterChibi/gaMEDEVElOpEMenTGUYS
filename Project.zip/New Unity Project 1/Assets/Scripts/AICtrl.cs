﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AICtrl : MonoBehaviour {

    public GameObject Char1;

    private Rigidbody2D rb2d;

    AudioSource audioSource;

    public AudioClip footStep1;
    public AudioClip footStep2;
    public AudioClip footStep3;
    public AudioClip footStep4;

    public float speed = 80f;
    public float detectionDistance = 200f;

    private float distance;
    private float distanceX;
    private float distanceY;
    private float collide;
    private float minPitch = 2f;
    private float maxPitch = 10f;
    private float musicDelay = 0f;
    private float musicRandom;
    private float footstepVolume = 0.25f;

    private float RandomWait;
    private float RandomNumber;
    
    private bool XlargerThanY;
    private bool diagonal;
    private bool isMoving = true;
    

    private Vector3 currentPos;



    // Use this for initialization
    void Start () {
        rb2d = GetComponent<Rigidbody2D>();
        audioSource = GetComponent<AudioSource>();
        audioSource.pitch = maxPitch / 2;
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        
        collide = GetComponent<BoxCollideTrigger>().collide;
        distance = Mathf.Sqrt(Mathf.Pow(currentPos.x - Char1.transform.position.x, 2.0f) + Mathf.Pow(currentPos.y - Char1.transform.position.y, 2.0f));
        distanceX = Mathf.Abs(currentPos.x - Char1.transform.position.x);
        distanceY = Mathf.Abs(currentPos.y - Char1.transform.position.y);
        currentPos = transform.position;
       
        if (distanceX>distanceY)
        {
            XlargerThanY = true;
        }
        else
        {
            XlargerThanY = false;
        }

        if (!Char1.GetComponent<Ctrl>().IsPaused)
        {
            AIMove();
            footsteps();
        }
	}

    void AIMove()
    {
        float moveHorizontal = 0;
        float moveVertical = 0;

        if (distance < detectionDistance && distance > 5)
        {
            diagonal = false;
            if (((XlargerThanY && Mathf.Rad2Deg * Mathf.Asin((Mathf.Round((distanceY / distance) * 100f)) / 100f) > 22.5) &&
                (XlargerThanY && Mathf.Rad2Deg * Mathf.Asin((Mathf.Round((distanceY / distance) * 100f)) / 100f) < 67.5)) ||
                ((!XlargerThanY && Mathf.Rad2Deg * Mathf.Asin((Mathf.Round((distanceX / distance) * 100f)) / 100f) > 22.5) &&
                (!XlargerThanY && Mathf.Rad2Deg * Mathf.Asin((Mathf.Round((distanceX / distance) * 100f)) / 100f) < 67.5)))
            {
                diagonal = true;
            }
            if (diagonal)
            {
                if (currentPos.x > Char1.transform.position.x)
                {
                    moveHorizontal = -speed/2;
                }
                else
                {
                    moveHorizontal = speed/2;
                }
                if (currentPos.y > Char1.transform.position.y)
                {
                    moveVertical = -speed/2;
                }
                else
                {
                    moveVertical = speed/2;
                }
            }
            else
            {
                if (XlargerThanY)
                {
                    if (currentPos.x > Char1.transform.position.x)
                    {
                        moveHorizontal = -speed;
                    }
                    else
                    {
                        moveHorizontal = speed;
                    }
                }
                else
                {
                    if (currentPos.y > Char1.transform.position.y)
                    {
                        moveVertical = -speed;
                    }
                    else
                    {
                        moveVertical = speed;
                    }
                }
            }
        }
        else
        {
           if (RandomWait == 0)
            {
                RandomNumber = Random.Range(1, 9);
                RandomWait = Random.Range(20, 46);
            } 

            if (RandomNumber == 1)
            {
                moveHorizontal = -speed;
            }
            if (RandomNumber == 2)
            {
                moveHorizontal = -speed/2;
                moveVertical = speed/2;
            }
            if (RandomNumber == 3)
            {
                moveVertical = speed;
            }
            if (RandomNumber == 4)
            {
                moveHorizontal = speed / 2;
                moveVertical = speed / 2;
            }
            if (RandomNumber == 5)
            {
                moveHorizontal = speed;
            }
            if (RandomNumber == 6)
            {
                moveHorizontal = speed / 2;
                moveVertical = -speed / 2;
            }
            if (RandomNumber == 7)
            {
                moveVertical = -speed;
            }
            if (RandomNumber == 8)
            {
                moveHorizontal = -speed / 2;
                moveVertical = -speed / 2;
            }
            RandomWait--;
        }
        Vector2 movement = new Vector2(moveHorizontal, moveVertical);

        rb2d.MovePosition(rb2d.position + movement * Time.deltaTime);
        
    }

    private void footsteps()
    {
        if (isMoving && musicDelay == 0)
        {
            audioSource.pitch = Random.Range(minPitch, maxPitch);
            musicRandom = Random.Range(0, 4);

            if (musicRandom == 0)
            {
                audioSource.PlayOneShot(footStep1, footstepVolume);
            }
            if (musicRandom == 1)
            {
                audioSource.PlayOneShot(footStep2, footstepVolume);
            }
            if (musicRandom == 2)
            {
                audioSource.PlayOneShot(footStep3, footstepVolume);
            }
            if (musicRandom == 3)
            {
                audioSource.PlayOneShot(footStep4, footstepVolume);
            }

            musicDelay = 2f;
        }

        if (isMoving && musicDelay != 0)
        {
            audioSource.pitch = Random.Range(minPitch, maxPitch);
            musicDelay -= 0.125f;
            musicDelay = Mathf.Round(musicDelay * 1000) / 1000;
        }

        if (!isMoving)
        {
            audioSource.Stop();
        }
    }
}
