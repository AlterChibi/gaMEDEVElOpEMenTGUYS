﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinimapController : MonoBehaviour {

    public GameObject char1;
    public GameObject enemy;
    public GameObject playermarker;
    public GameObject enemymarker;

    // Use this for initialization
    void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
        float distance = Mathf.Sqrt(Mathf.Pow(char1.transform.position.x - enemy.transform.position.x, 2.0f) + Mathf.Pow(char1.transform.position.y - enemy.transform.position.y, 2.0f));
        
        if (distance < char1.GetComponent<Ctrl>().detectionDistance)
        {
            enemymarker.transform.position = new Vector3(enemymarker.transform.position.x,enemymarker.transform.position.y,-1f);
        }
        else
        {
            enemymarker.transform.position = new Vector3(enemymarker.transform.position.x, enemymarker.transform.position.y, -13f);
        }
	}
}
