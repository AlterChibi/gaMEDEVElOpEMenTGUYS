﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinimapDetectionCirclePlayer : MonoBehaviour {

    public GameObject char1;

	// Use this for initialization
	void Start () {
        float detectionDistance = char1.GetComponent<Ctrl>().detectionDistance;
        detectionDistance = detectionDistance / 22.22222f;
        transform.localScale = new Vector3(detectionDistance,detectionDistance,1f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
