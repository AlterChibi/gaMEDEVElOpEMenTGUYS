﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinimapPlayerMarker : MonoBehaviour
{
    
    public GameObject char1;
    public GameObject minimap;

    private Vector3 charPos;
    private Vector3 offset;
    // Use this for initialization
    void Start()
    {


    }

    // Update is called once per frame
    void Update()
    {
        offset = minimap.transform.position;
        charPos = char1.transform.position;
        float charPosX = charPos.x / 15;
        float charPosY = charPos.y / 15;
        transform.position = new Vector3(charPosX + offset.x, charPosY + offset.y, transform.position.z);
    }
}
