﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinimapDetectionCircleEnemy : MonoBehaviour {

    public GameObject enemy;

    // Use this for initialization
    void Start()
    {
        float detectionDistance = enemy.GetComponent<AICtrl>().detectionDistance;
        detectionDistance = detectionDistance / 22.22222f;
        transform.localScale = new Vector3(detectionDistance, detectionDistance, 1f);
    }

    // Update is called once per frame
    void Update () {
		
	}
}
