﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Accessor : MonoBehaviour
{
    private void Start()
    {
        {

        }
    }
}

public class Interaction : MonoBehaviour {

    public GameObject BoxText;
    public GameObject Quad;
    public GameObject BoxTextBox;
    public GameObject EnemyTest;
    public GameObject EnemyText;
    public GameObject EnemyTextBox;

    private float collideBox;
    private float collideEnemy;

    private Vector3 EnemyPos;
    private Vector3 EnemyTextOffset = new Vector3(0f, 20f, 0f);
    private Vector3 EnemyTextBoxOffset = new Vector3(0f, 29f, 0f);


    // Use this for initialization
    void Start () {
        BoxText.gameObject.SetActive(false);
        BoxTextBox.gameObject.SetActive(false);
        EnemyText.gameObject.SetActive(false);
        EnemyTextBox.gameObject.SetActive(false);
}
	
	// Update is called once per frame
	void Update () {
        collideBox = Quad.GetComponent<BoxCollideTrigger>().collide;
        collideEnemy = EnemyTest.GetComponent<BoxCollideTrigger>().collide;
        EnemyPos = EnemyTest.transform.position;

        if (collideBox == 1 || collideBox == 2)
        {
            BoxText.gameObject.SetActive(true);
            BoxTextBox.gameObject.SetActive(true);
        }
        if (collideBox == 3)
        {
            BoxText.gameObject.SetActive(false);
            BoxTextBox.gameObject.SetActive(false);
        }
        if (collideEnemy == 1 || collideEnemy == 2)
        {
            EnemyText.transform.position = EnemyPos + EnemyTextOffset;
            EnemyTextBox.transform.position = EnemyPos + EnemyTextBoxOffset;
            EnemyText.gameObject.SetActive(true);
            EnemyTextBox.gameObject.SetActive(true);
        }
        if (collideEnemy == 3)
        {
            EnemyText.gameObject.SetActive(false);
            EnemyTextBox.gameObject.SetActive(false);
        }
    }
}
