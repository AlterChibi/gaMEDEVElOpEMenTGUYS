﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Accessor : MonoBehaviour
{
    private void Start()
    {
        {

        }
    }
}

public class Interaction : MonoBehaviour {

    public GameObject BoxText;
    public GameObject Quad;
    public GameObject BoxTextBox;
    private float collideBox;
    
    
	// Use this for initialization
	void Start () {
        BoxText.gameObject.SetActive(false);
        BoxTextBox.gameObject.SetActive(false);
}
	
	// Update is called once per frame
	void Update () {
        collideBox = Quad.GetComponent<BoxCollideTrigger>().collide;
        if (collideBox == 1 || collideBox == 2)
        {
            BoxText.gameObject.SetActive(true);
            BoxTextBox.gameObject.SetActive(true);
        }
        if (collideBox == 3)
        {
            BoxText.gameObject.SetActive(false);
            BoxTextBox.gameObject.SetActive(false);
        }
    }
}
