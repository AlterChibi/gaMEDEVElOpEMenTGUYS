﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button : MonoBehaviour {

    public GameObject Char1;
    public GameObject Pause;
    public GameObject Options;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void changePause ()
    {
        Char1.GetComponent<Ctrl>().ChangePause();
    }

    public void changeOptions()
    {
        Options.gameObject.SetActive(true);
        Pause.gameObject.SetActive(false);
    }

    public void changeBack()
    { 
        Pause.gameObject.SetActive(true);
        Options.gameObject.SetActive(false);
    }
}
