﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour {

    public GameObject Char1;

    private Vector3 offset;
	// Use this for initialization
	void Start () {
        offset = transform.position - Char1.transform.position;
	}
	
	// Update is called once per frame
	void LateUpdate () {
        Vector3 NextPosition = transform.position;
        NextPosition.z = Char1.transform.position.z;
        if (!(Char1.transform.position.y >= 260 || Char1.transform.position.y <= -260))
        {
            NextPosition.y = Char1.transform.position.y;
        }
        else
        {
            if (Char1.transform.position.y >= 260)
            {
                NextPosition.y = 260;
            }
            if (Char1.transform.position.y <= -260)
            {
                NextPosition.y = -260;
            }
        }
        if (!(Char1.transform.position.x >= 530 || Char1.transform.position.x <= -530))
        {
            NextPosition.x = Char1.transform.position.x;
        }
        else
        {
            if (Char1.transform.position.x >= 530)
            {
                NextPosition.x = 530;
            }
            if (Char1.transform.position.x <= -530)
            {
                NextPosition.x = -530;
            }
        }
        transform.position = NextPosition + offset;
        
	}
}
