﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour {

    public GameObject Char1;

    private Vector3 offset;
	// Use this for initialization
	void Start () {
        offset = transform.position - Char1.transform.position;
	}
	
	// Update is called once per frame
	void LateUpdate () {
        Vector3 NextPosition = transform.position;
        NextPosition.z = Char1.transform.position.z;
        if (!(Char1.transform.position.y >= 260 || Char1.transform.position.y <= -260))
        {
            NextPosition.y = Char1.transform.position.y;
        }
        else
        {
            if (Char1.transform.position.y >= 260)
            {
                NextPosition.y = 260;
            }
            if (Char1.transform.position.y <= -260)
            {
                NextPosition.y = -260;
            }
        }
        if (!(Char1.transform.position.x >= 490 || Char1.transform.position.x <= -490))
        {
            NextPosition.x = Char1.transform.position.x;
        }
        else
        {
            if (Char1.transform.position.x >= 490)
            {
                NextPosition.x = 485;
            }
            if (Char1.transform.position.x <= -485)
            {
                NextPosition.x = -485;
            }
        }
        transform.position = NextPosition + offset;
        
	}
}
