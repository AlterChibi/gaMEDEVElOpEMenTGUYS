﻿using UnityEngine;
using System.Collections;

public class Ctrl : MonoBehaviour
{
	public float maxSpeed = 100.0f;
    public GameObject Quad;
    public GameObject Pause;
    public GameObject Options;

    public AudioClip footStep1;
    public AudioClip footStep2;
    public AudioClip footStep3;
    public AudioClip footStep4;

    private Rigidbody2D rb2d;

    private float halfSpeed;
    private float speed;
    private float minPitch = 2f;
    private float maxPitch = 10f;
    private float musicDelay = 0f;
    private float musicRandom;
    private float footstepVolume = 0.25f;

    public float detectionDistance = 300f;

    public bool IsPaused = false;
    public bool PauseBuffer = true;
    public bool CanPause = true;

    private bool isMoving = false;

    AudioSource audioSource;

   
    private void Start()
    {
        Pause.gameObject.SetActive(false);
        Options.gameObject.SetActive(false);
        halfSpeed = maxSpeed / 2;
        rb2d = GetComponent<Rigidbody2D>();
        audioSource = GetComponent<AudioSource>();
        audioSource.pitch = maxPitch / 2;
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Escape) && PauseBuffer && CanPause)
        {
            ChangePause();
        }
        if (!Input.GetKey(KeyCode.Escape) && CanPause)
        {
            PauseBuffer = true;
        }
        if(Input.GetKey(KeyCode.E))
        {
            CanPause = true;
        }
    }

    void FixedUpdate()
    {
        
        float moveHorizontal;
        float moveVertical;
        if (!IsPaused)
        {
            if (((Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))) ||
                    ((Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) && (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))) ||
                    ((Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) && (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))) ||
                    ((Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))))
            {
                speed = halfSpeed;
            }
            else
            {
                speed = maxSpeed;
            }
            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
            {
                moveHorizontal = -speed;
                isMoving = true;
            }
            else if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
            {
                moveHorizontal = speed;
                isMoving = true;
            }
            else
            {
                moveHorizontal = 0;
            }
            if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
            {
                moveVertical = speed;
                isMoving = true;
            }
            else if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
            {
                moveVertical = -speed;
                isMoving = true;
            }
            else
            {
                moveVertical = 0;
            }
            if (moveHorizontal == 0 && moveVertical == 0)
            {
                isMoving = false;
            }
            Vector2 movement = new Vector2(moveHorizontal, moveVertical);

            rb2d.MovePosition(rb2d.position + movement * Time.deltaTime);

            if(isMoving && musicDelay == 0)
            {
                audioSource.pitch = Random.Range(minPitch,maxPitch);
                musicRandom = Random.Range(0, 4);
                if (musicRandom == 0)
                {
                    audioSource.PlayOneShot(footStep1, footstepVolume);
                }
                if (musicRandom == 1)
                {
                    audioSource.PlayOneShot(footStep2, footstepVolume);
                }
                if (musicRandom == 2)
                {
                    audioSource.PlayOneShot(footStep3, footstepVolume);
                }
                if (musicRandom == 3)
                {
                    audioSource.PlayOneShot(footStep4, footstepVolume);
                }
                musicDelay = 2f;
            }
            if (isMoving && musicDelay != 0)
            {
                audioSource.pitch = Random.Range(minPitch, maxPitch);
                musicDelay -= 0.125f;
                musicDelay = Mathf.Round(musicDelay * 1000) / 1000;
            }
            
            if (!isMoving)
            {
                audioSource.Stop();
            }

        }
    }

    public void ChangePause()
    {
        IsPaused = !IsPaused;
        Pause.gameObject.SetActive(IsPaused);
        PauseBuffer = false;
    }

}