﻿using UnityEngine;
using System.Collections;

public class Ctrl : MonoBehaviour
{
	public float maxSpeed = 5.0f;
    public GameObject Quad;
    public GameObject BorderLeft;
    public GameObject BorderRight;
    public GameObject BorderTop;
    public GameObject BorderBottom;
    public GameObject Pause;
    public GameObject Options;

    private float BorderLeftT;
    private float BorderRightT;
    private float BorderTopT;
    private float BorderBottomT;
    private float halfSpeed;
    private float speed;

    public bool IsPaused = false;
    public bool canPause = true;

   
    private void Start()
    {
        Pause.gameObject.SetActive(false);
        Options.gameObject.SetActive(false);
        halfSpeed = maxSpeed / 2;
    }

    void Update ()
	{

        BorderLeftT = BorderLeft.GetComponent<BoxCollideTrigger>().collide;
        BorderRightT = BorderRight.GetComponent<BoxCollideTrigger>().collide;
        BorderTopT = BorderTop.GetComponent<BoxCollideTrigger>().collide;
        BorderBottomT = BorderBottom.GetComponent<BoxCollideTrigger>().collide;

        if (!IsPaused)
        {
            if (((Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))) ||
                ((Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) && (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))) ||
                ((Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) && (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))) ||
                ((Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))))
            {
                speed = halfSpeed;
            }
            else
            {
                speed = maxSpeed;
            }
            if ((Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) && !(BorderLeftT == 2 || BorderLeftT == 1))
            {
                transform.position += Vector3.left * speed * Time.deltaTime;
            }
            if ((Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) && !(BorderRightT == 2 || BorderRightT == 1))
            {
                transform.position += Vector3.right * speed * Time.deltaTime;
            }
            if ((Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W)) && !(BorderTopT == 2 || BorderTopT == 1))
            {
                transform.position += Vector3.up * speed * Time.deltaTime;
            }
            if ((Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S)) && !(BorderBottomT == 2 || BorderBottomT == 1))
            {
                transform.position += Vector3.down * speed * Time.deltaTime;
            }
        }
        if (Input.GetKey(KeyCode.Escape) && canPause)
        {
            ChangePause();
        }
        if (!Input.GetKey(KeyCode.Escape))
        {
            canPause = true;
        }
        
    }

    public void ChangePause()
    {
        IsPaused = !IsPaused;
        Pause.gameObject.SetActive(IsPaused);
        canPause = false;
    }

}