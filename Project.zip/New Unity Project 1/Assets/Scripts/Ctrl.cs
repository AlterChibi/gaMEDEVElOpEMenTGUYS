﻿using UnityEngine;
using System.Collections;

public class Ctrl : MonoBehaviour
{
	public float maxSpeed = 5.0f;
    public GameObject Quad;
    public GameObject Pause;
    public GameObject Options;

    private Rigidbody2D rb2d;

    private float halfSpeed;
    private float speed;

    public bool IsPaused = false;
    public bool PauseBuffer = true;
    public bool CanPause = true;

   
    private void Start()
    {
        Pause.gameObject.SetActive(false);
        Options.gameObject.SetActive(false);
        halfSpeed = maxSpeed / 2;
        rb2d = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Escape) && PauseBuffer && CanPause)
        {
            ChangePause();
        }
        if (!Input.GetKey(KeyCode.Escape) && CanPause)
        {
            PauseBuffer = true;
        }
        if(Input.GetKey(KeyCode.E))
        {
            CanPause = true;
        }
    }

    void FixedUpdate()
    {
        
        float moveHorizontal;
        float moveVertical;
        if (!IsPaused)
        {
            if (((Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))) ||
                    ((Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) && (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))) ||
                    ((Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) && (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))) ||
                    ((Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))))
            {
                speed = halfSpeed;
            }
            else
            {
                speed = maxSpeed;
            }
            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
            {
                moveHorizontal = -speed;
            }
            else if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
            {
                moveHorizontal = speed;
            }
            else
            {
                moveHorizontal = 0;
            }
            if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
            {
                moveVertical = speed;
            }
            else if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
            {
                moveVertical = -speed;
            }
            else
            {
                moveVertical = 0;
            }

            Vector2 movement = new Vector2(moveHorizontal, moveVertical);

            rb2d.MovePosition(rb2d.position + movement * Time.deltaTime);
        }
    }

    public void ChangePause()
    {
        IsPaused = !IsPaused;
        Pause.gameObject.SetActive(IsPaused);
        PauseBuffer = false;
    }

}