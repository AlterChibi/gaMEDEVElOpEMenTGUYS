﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinimapEnemyMarker : MonoBehaviour {

    public GameObject Enemy;
    public GameObject minimap;

    private Vector3 enemyPos;
    private Vector3 offset;
	// Use this for initialization
	void Start () {

        
    }
	
	// Update is called once per frame
	void Update () {
        offset = minimap.transform.position;
        enemyPos = Enemy.transform.position;
        float enemyPosX = enemyPos.x / 15;
        float enemyPosY = enemyPos.y / 15;
        transform.position = new Vector3(enemyPosX+offset.x, enemyPosY+offset.y, transform.position.z);
	}
}
