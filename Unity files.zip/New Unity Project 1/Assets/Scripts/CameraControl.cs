﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour {

    public GameObject Char1;

    private Vector3 offset;
	// Use this for initialization
	void Start () {
        offset = transform.position - Char1.transform.position;
	}
	
	// Update is called once per frame
	void LateUpdate () {
        Vector3 NextPosition = transform.position;
        NextPosition.z = Char1.transform.position.z;
        if (!(Char1.transform.position.y >= 255 || Char1.transform.position.y <= -255))
        {
            NextPosition.y = Char1.transform.position.y;
        }
        else
        {
            if (Char1.transform.position.y >= 255)
            {
                NextPosition.y = 255;
            }
            if (Char1.transform.position.y <= -255)
            {
                NextPosition.y = -255;
            }
        }
        if (!(Char1.transform.position.x >= 465 || Char1.transform.position.y <= -465))
        {
            NextPosition.x = Char1.transform.position.x;
        }
        else
        {
            if (Char1.transform.position.x >= 465)
            {
                NextPosition.x = 465;
            }
            if (Char1.transform.position.x <= -465)
            {
                NextPosition.x = -465;
            }
        }
        transform.position = NextPosition + offset;
        
	}
}
